/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package taller2023_xml;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Slider;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Juan Carlos Vilarrubia
 */
public class MotoFormController implements Initializable {

    @FXML
    private TextField nombreClienteTextField;
    @FXML
    private TextField nifClienteTextField;
    @FXML
    private TextField matriculaVehiculoTextField;
    @FXML
    private TextField marcaVehiculoTextField;
    @FXML
    private TextField modeloVehiculoTextField;
    @FXML
    private Slider kmVehiculoSlider;
    @FXML
    private Label kmVehiculoLabel;
    @FXML
    private ComboBox<String> repMecanicoComboBox;
    @FXML
    private RadioButton repVehicleBreak;
    @FXML
    private RadioButton repVehicleTire;
    @FXML
    private RadioButton repVehicleGeneral;
    @FXML
    private RadioButton repVehicleBatery;
    @FXML
    private TextField repVehiclePrice;
    @FXML
    private DatePicker repVehicleStartDate;
    @FXML
    private DatePicker repVehicleEndDate;
    @FXML
    private Button motorcycleSaveButton;
    @FXML
    private Button motorcycleCancelButton;
    @FXML
    private CheckBox repCkeck;
    @FXML
    private TableView<RepairService> repVehicleTable;
    @FXML
    private TableColumn<RepairService, String> repMecanicoTableColumn;
    @FXML
    private TableColumn<RepairService, String> repServicioTableColumn;
    @FXML
    private TableColumn<RepairService, String> repPrecioTableColumn;
    @FXML
    private Pane clientPane;

    private List<RadioButton> serviceRadioButtons;
    private boolean isRepairChecked = false;
    private int lastRowChecked = -1;
    private ToggleGroup serviceRadioGroup;
    // para eliminar el focus del campo nombre para que se vea el placeholder
    private boolean firstTime = true;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        nombreClienteTextField.focusedProperty()
                .addListener((observer, oldValue, newValue) -> {
                    System.out.println("In initialize first time focus");
                    if (newValue && firstTime) {
                        clientPane.requestFocus();
                        System.out.println("Changing focus");
                        //nombreClienteTextField.clear();
                        firstTime = false;
                    }
                });

        serviceRadioButtons = new ArrayList<>();
        serviceRadioButtons.add(repVehicleTire);
        serviceRadioButtons.add(repVehicleBreak);
        serviceRadioButtons.add(repVehicleBatery);
        serviceRadioButtons.add(repVehicleGeneral);

        repMecanicoTableColumn.setCellValueFactory(new PropertyValueFactory<>("mechanic"));
        repServicioTableColumn.setCellValueFactory(new PropertyValueFactory<>("service"));
        repPrecioTableColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        serviceRadioGroup = buildRadioButtonsGroup(serviceRadioButtons);
        ckeckFirst(serviceRadioGroup);
        setStaff();

    }

    /**
     * Puebla el combo box con el nombre de los mecánicos del taller.
     */
    private void setStaff() {
        ObservableList<String> staff = FXCollections.observableArrayList(
                "Gregorio Samsa",
                "Federico Espasa",
                "Pedro Paramo",
                "Fergus Kilpatrick",
                "Martín Fierro"
        );

        repMecanicoComboBox.setItems(staff);
    }

    /**
     * Crea un grupo con la lista de radio buttons pasados como parámetro.
     *
     * @param radioButtons lista de radio buttons
     * @return el grupo de rasio buttons
     */
    private ToggleGroup buildRadioButtonsGroup(List<RadioButton> radioButtons) {
        ToggleGroup tg = new ToggleGroup();

        for (RadioButton radio : radioButtons) {
            radio.setToggleGroup(tg);
        }

        return tg;
    }

    /**
     * Hace un check al primer elemento
     *
     * @param tg grupo de elementos seleccionables
     */
    private void ckeckFirst(ToggleGroup tg) {
        RadioButton first = (RadioButton) tg.getToggles().get(0);
        first.setSelected(true);
    }

    @FXML
    /**
     * Cambia la visibilidad del grupo de radio buttons corespondiente a los
     * servicios realizados según el estado del sheckbox reparación.
     */
    private void toggleVisible() {
        isRepairChecked = repCkeck.isSelected();
        //ckeckFirst(serviceRadioGroup);

        for (RadioButton radio : serviceRadioButtons) {
            radio.setDisable(!isRepairChecked);
        }
    }

    @FXML
    /**
     * Muestra los kilometros seleccionados desde el slider de kilometraje.
     */
    private void displayKmSelectedValue(Event event) {
        Double kilometers = kmVehiculoSlider.getValue();

        kmVehiculoLabel.setText(String.valueOf(kilometers.intValue()));
    }

    @FXML
    /**
     * Agrega una reparación a la tabla de reparaciones.
     */
    private void addServiceRow(ActionEvent event) {

        String mechanic = repMecanicoComboBox.getSelectionModel().getSelectedItem();
        RadioButton selectedRadio = (RadioButton) serviceRadioGroup.getSelectedToggle();
        String service = selectedRadio.getText();
        String price = repVehiclePrice.getText();

        RepairService rs = new RepairService(mechanic, service, price);

        if (isRepairChecked && rs.isValid()) {

            Double fPrice = Double.valueOf(price);

            repVehicleTable.getItems()
                    .add(new RepairService(mechanic, service, String.format("%.2f", fPrice)));

        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Verifique que a seleccionado:\n\tMecánico\n\tServicio\n\tPrecio válido");
            alert.setHeaderText("Error de validación");
            alert.setTitle("Añadir");
            alert.showAndWait();
        }

    }

    @FXML
    /**
     * Pide confirmación y elimina la fila seleccionada de la tabla de
     * reparaciones, si no hay fila seleccionada muestra un mensaje informando
     * al usuario.
     */
    private void deleteServiceRow(ActionEvent event) {
        TableView.TableViewSelectionModel<RepairService> selectionModel
                = repVehicleTable.getSelectionModel();
        Alert alert;

        if (selectionModel.getSelectedCells().isEmpty()) {
            alert = new Alert(Alert.AlertType.ERROR, "Debe seleccionar una fila de la tabla.");
            alert.setHeaderText("Ninguna fila seleccionada");
            alert.setTitle("Eliminar");
            alert.showAndWait();

        } else {
            alert = new Alert(Alert.AlertType.CONFIRMATION, "¿Esta seguro de eliminar este registro?");
            alert.setTitle("Eliminar");
            alert.showAndWait().ifPresent(action -> {
                if (action == ButtonType.OK) {
                    int index = selectionModel.getSelectedIndex();
                    repVehicleTable.getItems().remove(index);
                }
            });
        }
    }

    @FXML
    /**
     * Muestra un mensaje informando la información se ha guardado con éxito y
     * cierra la ventana.
     */
    private void saveMotoData(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, "Información guardada con éxito");
        alert.setTitle("Guardar");
        alert.setHeaderText("Éxito");
        alert.showAndWait();
        Stage stage = (Stage) motorcycleSaveButton.getScene().getWindow();
        stage.close();
    }

    @FXML
    /**
     * Pregunta al usuario si desea abandorar sin guardar la información
     * pendiente.
     */
    private void cancelMotodata(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "¿Desea salir sin guardar los cambios?");
        alert.setTitle("Cancelar");
        alert.showAndWait().ifPresent(action -> {
            if (action == ButtonType.OK) {
                Stage stage = (Stage) motorcycleCancelButton.getScene().getWindow();
                stage.close();
            }
        });
    }

    /**
     * Cambia el estado de selección de la fila en en la tabla.
     */
    private void toggleRowSelection() {
        //System.out.println("toggle");
        TableView.TableViewSelectionModel<RepairService> selectionModel
                = repVehicleTable.getSelectionModel();

        int focusedRow = selectionModel.getFocusedIndex();

        if (focusedRow >= 0 && focusedRow == lastRowChecked) {
            selectionModel.clearSelection(focusedRow);
            lastRowChecked = -1;
        } else {
            lastRowChecked = focusedRow;
        }

    }

    @FXML
    /**
     * Cambia la selección de la fila al pulsar la barra espaciadora
     */
    private void toggleRowSelectionKey(KeyEvent event) {
        TableView.TableViewSelectionModel<RepairService> selectionModel
                = repVehicleTable.getSelectionModel();

        int focusedRow = selectionModel.getFocusedIndex();

        if (event.getCode() == KeyCode.SPACE) {
            toggleRowSelection();
        }

        if (event.getCode() == KeyCode.DOWN || event.getCode() == KeyCode.UP) {
            lastRowChecked = focusedRow;
        }
    }

    @FXML
    /**
     * Cambia la selección de la fila al pulsar con el ratón sobre ella
     */
    private void toggleRowSelectionMouse(MouseEvent event) {
        toggleRowSelection();
    }
}
