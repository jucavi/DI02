/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML2.java to edit this template
 */
package taller2023_xml;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.MenuItem;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * FXML Controller class.
 *
 * @author Juan Carlos Vilarrubia
 */
public class PantallaPrincipalController implements Initializable {

    private Parent root;
    private Scene scene;
    private Stage stage;

    @FXML
    private MenuItem menuItemBike;

    @FXML
    private MenuItem menuItemMotorcycle;

    @FXML
    private Button buttonBike;

    @FXML
    private Button buttonMotorcycle;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initializePrincipalPane();
    }

    /**
     * Agrega la imágenes de fondo en los botones bicicleta y motocicleta.
     */
    private void initializePrincipalPane() {
        //System.out.println("Principal panel initialized.");

        Image imgBike = new Image(getClass().getResourceAsStream("images/bicycle.png"));
        ImageView bikeIv = new ImageView(imgBike);
        bikeIv.setFitWidth(80);
        bikeIv.setPreserveRatio(true);
        bikeIv.setSmooth(true);

        buttonBike.setGraphic(bikeIv);
        //System.out.println(buttonBike.getInsets().toString());
        //System.out.println(buttonBike.getOpaqueInsets());

        Image imgMotorcycle = new Image(getClass().getResourceAsStream("images/motorcycle.png"));
        ImageView motorIv = new ImageView(imgMotorcycle);
        motorIv.setFitWidth(80);
        motorIv.setPreserveRatio(true);
        motorIv.setSmooth(true);

        buttonMotorcycle.setGraphic(motorIv);
    }

    @FXML
    /**
     * Muestra ventana de información sobre la versión de la aplicación.
     */
    private void showAboutAlert() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, "Gestión de Taller V1.1");
        alert.setTitle("Info");
        alert.setHeaderText("Version");
        alert.setResizable(false);
        alert.showAndWait();
    }

    @FXML
    /**
     * Lanza el formulario de Bicicleta.
     */
    private void onActionShowBikeForm(javafx.event.ActionEvent event) {
        //System.out.println("onAction launch Bike");
        try {
            Image icon = new Image(getClass().getResourceAsStream("images/icono_taller.png"));

            root = FXMLLoader.load(getClass().getResource("BikeForm.fxml"));
            scene = new Scene(root);
            stage = new Stage();

            stage.setTitle("Bicicleta");
            stage.getIcons().add(icon);
            stage.initModality(Modality.NONE);

            stage.setScene(scene);
            stage.show();

        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }

    @FXML
    /**
     * Lanza el formulario de Motocicleta.
     */
    private void onActionShowMotoForm(javafx.event.ActionEvent event) {
        //System.out.println("onAction launch Motorcycle");
        try {
            Image icon = new Image(getClass().getResourceAsStream("images/icono_taller.png"));

            root = FXMLLoader.load(getClass().getResource("MotoForm.fxml"));
            scene = new Scene(root);
            stage = new Stage();

            stage.setTitle("Motocicleta");
            stage.getIcons().add(icon);
            stage.initModality(Modality.APPLICATION_MODAL);

            stage.setScene(scene);
            stage.show();

        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }
}
