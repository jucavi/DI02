/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package taller2023_xml;

/**
 * Clase que permite crar un servicio de reparación.
 *
 * @author Juan Carlos Vilarrubia
 */
public class RepairService {

    private String mechanic;
    private String service;
    private String price;

    public RepairService(String mechanic, String service, String price) {
        this.mechanic = mechanic;
        this.service = service;
        this.price = price;
    }

    public String getMechanic() {
        return mechanic;
    }

    public String getService() {
        return service;
    }

    public String getPrice() {
        return price;
    }

    /**
     * Validacion Básica.
     *
     * @return true, si el mecánico no es null, servicio no es null y el precio
     * es un número mayor que cero;
     */
    public boolean isValid() {
        if (mechanic == null) {
            return false;
        }

        if (service == null) {
            return false;
        }

        try {
            Double p = Double.valueOf(price);

            if (p <= 0) {
                return false;
            }
        } catch (NumberFormatException e) {
            return false;
        }

        return true;
    }
}
